# bot.py
import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import random, string, json
from flask import Flask, request, jsonify
import threading
from datetime import datetime, timedelta

TOKEN = "7633079350:AAE0thszpZIdDzE1n_RcjXlBDiFkTa3Zgwk"
bot = telebot.TeleBot(TOKEN)

# Keys storage in memory with expiry and optional device/user binding
keys_db = {}  # key: {"duration":days, "expires":datetime_string, "user":telegram_id}

# ===== Key Generation =====
def generate_key(duration, user_id=None):
    key = ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))
    expires = datetime.now() + timedelta(days=duration)
    keys_db[key] = {"duration": duration, "expires": expires.strftime("%Y-%m-%d %H:%M:%S"), "user": user_id}
    return key

# ===== Telegram Menu =====
@bot.message_handler(commands=['start'])
def start(message):
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🆕 Generate Key", callback_data="gen_key"))
    markup.add(InlineKeyboardButton("🗑 Delete Key", callback_data="del_key"))
    markup.add(InlineKeyboardButton("📜 View Active Keys", callback_data="view_keys"))
    bot.send_message(message.chat.id, "Welcome! Choose an option:", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: True)
def callback(call):
    chat_id = call.message.chat.id

    if call.data == "gen_key":
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("1️⃣ 1 Day Key", callback_data="key_1"))
        markup.add(InlineKeyboardButton("3️⃣ 30 Day Key", callback_data="key_30"))
        markup.add(InlineKeyboardButton("6️⃣ 60 Day Key", callback_data="key_60"))
        bot.edit_message_text("Select key duration:", chat_id, call.message.message_id, reply_markup=markup)

    elif call.data.startswith("key_"):
        duration = int(call.data.split("_")[1])
        key = generate_key(duration, user_id=call.from_user.id)
        bot.edit_message_text(f"✅ Key: `{key}`\n⏳ Duration: {duration} day(s)", chat_id, call.message.message_id, parse_mode="Markdown")

    elif call.data == "view_keys":
        if not keys_db:
            text = "No active keys."
        else:
            text = "📜 Active Keys:\n"
            for k, info in keys_db.items():
                text += f"{k} - {info['duration']} day(s) - Expires: {info['expires']}\n"
        bot.edit_message_text(text, chat_id, call.message.message_id)

    elif call.data == "del_key":
        if not keys_db:
            bot.answer_callback_query(call.id, "❌ No keys to delete.")
            return
        markup = InlineKeyboardMarkup()
        for k in keys_db:
            markup.add(InlineKeyboardButton(f"🗑 {k}", callback_data=f"del_{k}"))
        bot.edit_message_text("Select key to delete:", chat_id, call.message.message_id, reply_markup=markup)

    elif call.data.startswith("del_"):
        key = call.data.split("del_")[1]
        if key in keys_db:
            del keys_db[key]
            bot.edit_message_text(f"✅ Key `{key}` deleted!", chat_id, call.message.message_id)
        else:
            bot.answer_callback_query(call.id, "❌ Key not found.")

# ===== Flask API to verify keys =====
app = Flask(__name__)

@app.route("/verify", methods=["POST"])
def verify():
    data = request.json
    key = data.get("key")
    user_id = data.get("user_id", None)  # optional device/user bind
    info = keys_db.get(key)
    if info:
        expires = datetime.strptime(info["expires"], "%Y-%m-%d %H:%M:%S")
        if datetime.now() > expires:
            return jsonify({"status":"expired"})
        # optional user/device check
        if user_id and info["user"] != user_id:
            return jsonify({"status":"invalid"})
        return jsonify({"status":"valid", "duration": info["duration"]})
    return jsonify({"status":"invalid"})

# ===== Run Bot + API Together =====
def run_flask():
    app.run(host="0.0.0.0", port=5000)

threading.Thread(target=run_flask).start()
bot.infinity_polling()